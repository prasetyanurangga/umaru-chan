const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const mondaySdk = require('monday-sdk-js');
const os = require('os');

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.json());

// Ambil API key monday.com dari environment variable (direkomendasikan untuk keamanan)
const MONDAY_API_KEY = process.env.MONDAY_API_KEY;
if (!MONDAY_API_KEY) {
    console.warn("Warning: MONDAY_API_KEY tidak ditemukan di environment variable.");
}
const monday = mondaySdk({ token: MONDAY_API_KEY });

// Contoh struktur data untuk menyimpan konfigurasi (dalam memori, untuk demonstrasi)
const configurations = {};

app.post('/configure', (req, res) => {
    /**
     * Menerima konfigurasi dari frontend dan menyimpannya.
     */
    try {
        const { boardId, endpointUrl, method = 'GET', params = {}, body, bodyType = 'json', mapping = {} } = req.body;

        if (!boardId || !endpointUrl || !mapping) {
            return res.status(400).json({ error: "Board ID, Endpoint URL, dan Mapping harus disediakan." });
        }

        configurations[boardId] = {
            endpointUrl,
            method: method.toUpperCase(),
            params,
            body,
            bodyType: bodyType.toLowerCase(),
            mapping
        };

        res.status(200).json({ message: `Konfigurasi untuk Board ID ${boardId} berhasil disimpan.` });
    } catch (error) {
        console.error("Error during configuration:", error);
        res.status(500).json({ error: error.message });
    }
});

app.post('/trigger/:boardId', async (req, res) => {
    /**
     * Memicu penarikan data dan pembaruan monday.com board.
     */
    const { boardId } = req.params;
    const config = configurations[boardId];

    if (!config) {
        return res.status(404).json({ error: `Tidak ada konfigurasi untuk Board ID ${boardId}.` });
    }

    const { endpointUrl, method, params, body, bodyType, mapping } = config;

    try {
        const headers = {};
        if (body && bodyType === 'json') {
            headers['Content-Type'] = 'application/json';
        }

        const response = await axios.request({
            method,
            url: endpointUrl,
            params,
            headers,
            data: bodyType === 'json' && body ? body : (bodyType === 'raw' ? body : undefined),
        });
        response.data; // Data dari API

        await processAndUpdateMonday(boardId, response.data, mapping);
        res.status(200).json({ message: `Data dari ${endpointUrl} berhasil diproses dan diperbarui untuk Board ID ${boardId}.` });
    } catch (error) {
        console.error("Error during API call or monday update:", error);
        res.status(500).json({ error: error.message });
    }
});

async function processAndUpdateMonday(boardId, apiData, mapping) {
    /**
     * Memproses respons API dan membuat item di monday.com board.
     */
    const itemsToCreate = [];
    if (Array.isArray(apiData)) {
        for (const itemData of apiData) {
            const itemValues = {};
            for (const mondayColumnId in mapping) {
                const apiPath = mapping[mondayColumnId];
                try {
                    const value = getNestedValue(itemData, apiPath);
                    if (value !== undefined && value !== null) {
                        itemValues[mondayColumnId] = String(value);
                    }
                } catch (error) {
                    console.error(`Error processing path '${apiPath}':`, error);
                }
            }
            if (Object.keys(itemValues).length > 0) {
                itemsToCreate.push({ name: itemData.name || 'New Item', column_values: JSON.stringify(itemValues) });
            }
        }

        if (itemsToCreate.length > 0) {
            try {
                const response = await monday.items.createMultipleItems(boardId, itemsToCreate);
                if (response && response.error) {
                    console.error("Error creating items in monday:", response.error);
                }
            } catch (error) {
                console.error("Error interacting with monday API:", error);
            }
        }
    } else {
        console.warn("Respons API bukan berupa array, perlu penanganan yang berbeda.");
    }
}

function getNestedValue(obj, path) {
    /**
     * Mendapatkan nilai nested dari objek berdasarkan path string (misalnya, 'data.items[0].name').
     */
    try {
        return path.split('.').reduce((o, key) => {
            const match = key.match(/([^\[]+)\[(\d+)\]/);
            if (match) {
                const prop = match[1];
                const index = parseInt(match[2], 10);
                return o && o[prop] && Array.isArray(o[prop]) ? o[prop][index] : undefined;
            }
            return o && o[key];
        }, obj);
    } catch (error) {
        return undefined;
    }
}

app.listen(port, () => {
    console.log(`Server berjalan di http://localhost:${port} atau port ${port} di monday code`);
});